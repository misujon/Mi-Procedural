<?php
/**
 * Author: Monirul Islam
 * Author Url: http://www.misujon.com/
 */

function mi_header(){
    require_once 'header.php';
}

function mi_footer(){
    require_once 'footer.php';
}

function mi_nav(){
    require_once 'nav.php';
}

function mi_sidebar(){
    require_once 'sidebar.php';
}