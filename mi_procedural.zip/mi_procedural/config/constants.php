<?php
/**
 * Author: Monirul Islam
 * Author Url: http://www.misujon.com/
 */

/*==================================== MI DB CONFIGURATION ======================================*/
define('MI_DB_HOST', 'localhost');
define('MI_DB_NAME', 'mi_pos');
define('MI_DB_USER', 'root');
define('MI_DB_PASS', '');
/*==================================== MI DB CONFIGURATION END ==================================*/

/*==================================== MI SMTP MAIL CONFIGURATION ======================================*/
define('MI_MAIL_HOST', 'smtp.gmail.com');
define('MI_MAIL_USER', '1000254@daffodil.ac');
define('MI_MAIL_PASS', 'monirul200');
define('MI_MAIL_LAYER', 'tls');
define('MI_MAIL_LAYER_CODE', '587');
define('MI_MAIL_FROM_NAME', 'Monirul Islam Sujon');
define('MI_MAIL_FROM_EMAIL', 'contact@misujon.com');
/*==================================== MI SMTP MAIL CONFIGURATION END ==================================*/
